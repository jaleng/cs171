make
cp wireframe_renderer data/
cd data
./wireframe_renderer scene_bunny1.txt 800 800 | display -&
