class Point {
public:
  int x;
  int y;
  explicit Point(int _x, int _y) : x{_x}, y{_y} {}
};
